#include <stdio.h> 
#include <time.h> 
#include "exercicioC.h"
#include <unistd.h>
#include <stdlib.h> 

/* NOMES: Lauane Alves Santana e Maria Luiza Martins Nunes*/
int main () { 

    struct timespec inicio, fim;
    
    int vetor[1000000];
    srand(time(NULL));

    for (int i = 0; i < 1000000; i++) { 
        vetor[i] = (rand() % 5000) + 1;
    }

    clock_gettime(CLOCK_MONOTONIC, &inicio);
    InsertionSort(vetor, 2000); 
    clock_gettime(CLOCK_MONOTONIC, &fim);
    printf("\n Tempo com Insertion Sort: %ld.%09ld", fim.tv_sec - inicio.tv_sec, fim.tv_nsec - inicio.tv_nsec);


    clock_gettime(CLOCK_MONOTONIC, &inicio);
    ShellSort(vetor, 2000); 
    clock_gettime(CLOCK_MONOTONIC, &fim);
    printf("\n Tempo com Shell Sort: %ld.%09ld\n\n", fim.tv_sec - inicio.tv_sec, fim.tv_nsec - inicio.tv_nsec);

}
