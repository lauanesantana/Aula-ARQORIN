/* NOMES: Lauane Alves Santana e Maria Luiza Martins Nunes*/ 

int InsertionSort(int *vetor, int n);

int ShellSort(int *vetor, int n);