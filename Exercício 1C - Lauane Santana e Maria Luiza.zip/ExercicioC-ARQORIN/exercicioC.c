/* Gere um vetor de 1000 valores inteiros aleatórios (simulando leituras de sensores) e
ordene-o utilizando ShellSort(). Meça (usando a função clock() ou clock_gettime() da
biblioteca time.h) o tempo de execução e compare com o tempo do InsertionSort()
tradicional para a mesma entrada. */ 

#include <stdio.h> 
#include <time.h> 
#include "exercicioC.h"
#include <unistd.h>

/* NOMES: Lauane Alves Santana e Maria Luiza Martins Nunes*/

int InsertionSort(int *vetor, int n){
    
    int j;

    for(int i = 1; i < n-1; i++){
        int chave = vetor[i];
        j = i - 1;

        while((j >= 0) && (vetor[j] > chave)){
            vetor[j + 1] = vetor[j];
            j = j - 1;
        }

        vetor[j + 1] = chave;
    }

}


int ShellSort(int *vetor, int n){
    int gap = n/2;

    int i, j;

    while(gap > 0){
    
        for(i = gap; i < n-1; i++){
            int chave = vetor[i];
            j = i - gap;
    
            while((j >= 0) && (vetor[j] > chave)){
                vetor[j + gap] = vetor[j];
                j = j - gap;
            }

            vetor[j + gap] = chave;
        }

        gap = gap/2;
    }

}